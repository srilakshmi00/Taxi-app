
<div class="sidebar col-lg-2 bg-info container-fluid float-left">
    <a href="dash.php">Dashboard</a>
    <a href="usrride.php">Rides</a>
    <a href="usrprofile.php">Profile</a>
  </div>