<nav class="nav nav-pills nav-justified">
<button class="nav-link btn btn-light" href="addlocation.php">All Location</button>
<button class="nav-link btn btn-light " href="locat.php">Add Location</button>
<button class="nav-link btn btn-light disabled" href="#">Edit Location</button>
</nav>