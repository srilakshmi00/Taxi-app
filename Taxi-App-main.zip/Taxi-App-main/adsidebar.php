
<div class="sidebar col-lg-2 container-fluid float-left list-group list-group-flush">
    <a href="admin.php">Dashboard</a>
    <a href="allusers.php">Users</a>
    <a href="allrides.php">Rides</a>
    <a href="addlocation.php">Location</a>
  </div>
